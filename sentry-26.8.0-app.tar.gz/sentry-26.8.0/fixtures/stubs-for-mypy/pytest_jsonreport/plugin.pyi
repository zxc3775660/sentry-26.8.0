class JSONReport:
    pass
