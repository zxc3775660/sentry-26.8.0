#!/bin/bash
set -e
export PYTHONPATH="/app/src"
export SENTRY_CONF="/etc/sentry"
export SENTRY_BUILD="26.8.0"

# 若輸入 --version，直接回傳指定版本；其餘參數帶入 Click runner
if [ "$1" = "--version" ]; then
    echo "sentry, version 26.8.0"
    exit 0
fi

exec python3 -c "
import sys
from sentry.runner.main import cli
sys.exit(cli.main(prog_name='sentry'))
" "$@"
