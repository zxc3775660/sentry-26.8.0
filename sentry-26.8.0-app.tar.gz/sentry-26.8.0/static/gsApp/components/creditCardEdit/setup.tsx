import {Fragment} from 'react';

import {Alert} from '@sentry/scraps/alert';

import {t} from 'sentry/locale';
import type {Organization} from 'sentry/types/organization';
import type {ApiQueryKey} from 'sentry/utils/api/apiQueryKey';
import {getApiUrl} from 'sentry/utils/api/getApiUrl';
import {decodeScalar} from 'sentry/utils/queryString';

import {CreditCardForm} from 'getsentry/components/creditCardEdit/form';
import type {FTCConsentLocation, Subscription} from 'getsentry/types';
import {
  trackGetsentryAnalytics,
  type GetsentryEventKey,
} from 'getsentry/utils/trackGetsentryAnalytics';

export interface CreditCardSetupProps {
  budgetTerm: string;
  organization: Organization;
  analyticsEvent?: GetsentryEventKey;
  buttonText?: string;
  location?: FTCConsentLocation;
  onCancel?: () => void;
  onSuccess?: () => void;
  onSuccessWithSubscription?: (data: Subscription) => void;
  referrer?: string;
}

export function CreditCardSetup({
  organization,
  referrer,
  onSuccess,
  onSuccessWithSubscription,
  onCancel,
  location,
  budgetTerm,
  buttonText,
  analyticsEvent,
}: CreditCardSetupProps) {
  return (
    <Fragment>
      {referrer?.includes('billing-failure') && (
        <Alert.Container>
          <Alert variant="warning" showIcon={false}>
            {t('Your credit card will be charged upon update.')}
          </Alert>
        </Alert.Container>
      )}
      <CreditCardForm
        organization={organization}
        location={location}
        budgetTerm={budgetTerm}
        buttonText={buttonText ?? t('Save Changes')}
        referrer={referrer}
        cardMode="setup"
        intentDataQueryKey={
          [
            getApiUrl('/organizations/$organizationIdOrSlug/payments/setup/', {
              path: {organizationIdOrSlug: organization.slug},
            }),
          ] satisfies ApiQueryKey
        }
        onCancel={onCancel ?? (() => {})}
        onSuccess={() => {
          onSuccess?.();
          if (analyticsEvent) {
            trackGetsentryAnalytics(analyticsEvent, {
              organization,
              referrer: decodeScalar(referrer),
            });
          }
        }}
        onSuccessWithSubscription={onSuccessWithSubscription}
      />
    </Fragment>
  );
}
