import {OrganizationFixture} from 'sentry-fixture/organization';

import {BillingConfigFixture} from 'getsentry-test/fixtures/billingConfig';
import {SubscriptionFixture} from 'getsentry-test/fixtures/subscription';
import {PlanTier} from 'getsentry-test/planTier';
import {render, screen} from 'sentry-test/reactTestingLibrary';

import PageUpsellOverlay from 'getsentry/components/features/pageUpsellOverlay';
import {SubscriptionStore} from 'getsentry/stores/subscriptionStore';

describe('PageUpsellOverlay', () => {
  let wrapper: any;
  afterEach(() => {
    if (wrapper) {
      wrapper.unmount();
    }
    wrapper = null;
  });

  const org = OrganizationFixture({access: ['org:billing']});
  MockApiClient.addMockResponse({
    url: `/customers/${org.slug}/billing-config/?tier=upsell`,
    body: BillingConfigFixture(PlanTier.AM2),
  });

  it('renders customSecondaryCTA', () => {
    const subscription = SubscriptionFixture({
      organization: org,
      canSelfServe: true,
      canTrial: false,
    });
    SubscriptionStore.set(org.slug, subscription);

    wrapper = render(
      <PageUpsellOverlay
        organization={org}
        customSecondaryCTA="My Text"
        features={[]}
        name=""
        positioningStrategy={jest.fn()}
        description=""
        requiredPlan=""
        source=""
      />,
      {organization: org}
    );
    expect(screen.queryByText('Learn More')).not.toBeInTheDocument();
    expect(screen.getByText('My Text')).toBeInTheDocument();
    expect(screen.getByText('Upgrade Plan')).toBeInTheDocument();
  });
  it('renders learn more', () => {
    const subscription = SubscriptionFixture({
      organization: org,
      canSelfServe: true,
      canTrial: false,
    });
    SubscriptionStore.set(org.slug, subscription);

    wrapper = render(
      <PageUpsellOverlay
        organization={org}
        features={[]}
        name=""
        positioningStrategy={jest.fn()}
        description=""
        requiredPlan=""
        source=""
      />,
      {organization: org}
    );
    expect(screen.getByText('Learn More')).toBeInTheDocument();
    expect(screen.getByText('Upgrade Plan')).toBeInTheDocument();
  });
  it('does not render CTA for non-self serve', () => {
    const subscription = SubscriptionFixture({
      organization: org,
      canSelfServe: false,
      canTrial: false,
    });
    SubscriptionStore.set(org.slug, subscription);

    wrapper = render(
      <PageUpsellOverlay
        organization={org}
        features={[]}
        name=""
        positioningStrategy={jest.fn()}
        description=""
        requiredPlan=""
        source=""
      />,
      {organization: org}
    );
    expect(screen.getByText('Learn More')).toBeInTheDocument();
    expect(screen.queryByText('Upgrade Plan')).not.toBeInTheDocument();
  });
});
