import {Button} from '@sentry/scraps/button';

import {t} from 'sentry/locale';
import type {Organization} from 'sentry/types/organization';

import {openUpsellModal} from 'getsentry/actionCreators/modal';

type Props = React.PropsWithChildren<{
  organization: Organization;
}>;

export function ProjectPerformanceScoreCard({organization}: Props) {
  return (
    <Button
      size="sm"
      variant="primary"
      onClick={() => openUpsellModal({organization, source: 'project-details'})}
    >
      {t('Learn More')}
    </Button>
  );
}
