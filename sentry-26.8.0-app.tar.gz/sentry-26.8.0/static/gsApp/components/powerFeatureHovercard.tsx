import styled from '@emotion/styled';

import {Button} from '@sentry/scraps/button';
import {Stack} from '@sentry/scraps/layout';

import {Hovercard} from 'sentry/components/hovercard';
import {IconLightning} from 'sentry/icons';
import {t} from 'sentry/locale';
import type {Organization} from 'sentry/types/organization';
import {useOrganization} from 'sentry/utils/useOrganization';

import {openUpsellModal} from 'getsentry/actionCreators/modal';
import PlanFeature from 'getsentry/components/features/planFeature';
import {withSubscription} from 'getsentry/components/withSubscription';
import type {Subscription} from 'getsentry/types';
import {displayPlanName} from 'getsentry/utils/billing';
import {trackGetsentryAnalytics} from 'getsentry/utils/trackGetsentryAnalytics';

interface PowerFeatureHovercardProps {
  /**
   * The set of features that are required for this feature. Used to
   * determine which plan is required for the feature.
   *
   * NOTE: If the user has all features the hovercard will NOT be hidden. It
   * is up to the parent component to decide whether this should be rendered.
   */
  features: Organization['features'];

  subscription: Subscription;
  children?: React.ReactNode;
  containerClassName?: string;
  containerDisplayMode?: React.ComponentProps<
    typeof StyledHovercard
  >['containerDisplayMode'];

  /**
   * The key passed to analytics when clicking learn more, as well as the key
   * used as the source when opening the landing modal.
   */
  id?: string;

  /**
   * When enabled the hovercard will indicate that *some* features will
   * require an upgraded plan.
   */
  partial?: boolean;

  /**
   * Replaces the default learn more button with a more subtle link text that
   * opens the upsell modal.
   */
  useLearnMoreLink?: boolean;
}

function PowerFeatureHovercard({
  id,
  containerClassName,
  containerDisplayMode,
  subscription,
  partial,
  features,
  children,
}: PowerFeatureHovercardProps) {
  const organization = useOrganization();
  const recordAnalytics = () => {
    trackGetsentryAnalytics('power_icon.clicked', {
      organization,
      subscription,
      source: id,
    });
  };

  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault();

    recordAnalytics();
    openUpsellModal({
      organization,
      source: id ?? '',
    });
  };

  const hoverBody = (
    <PlanFeature
      features={features}
      organization={organization}
      subscription={subscription}
    >
      {({plan}) => {
        const planName = displayPlanName(plan);

        return (
          <LearnMoreTextBody data-test-id="power-hovercard">
            <Stack gap="md">
              <div>
                {partial
                  ? t('Better With %s Plan', planName)
                  : t('Requires %s Plan', planName)}
              </div>
              <Button
                variant="primary"
                onClick={handleClick}
                data-test-id="power-learn-more"
                size="xs"
                icon={<IconLightning size="xs" />}
              >
                {t('Learn More')}
              </Button>
            </Stack>
          </LearnMoreTextBody>
        );
      }}
    </PlanFeature>
  );

  return (
    <StyledHovercard
      containerClassName={containerClassName}
      containerDisplayMode={containerDisplayMode}
      bodyClassName="power-icon"
      body={hoverBody}
      position="right"
      delay={200}
    >
      {children}
    </StyledHovercard>
  );
}

const LearnMoreTextBody = styled('div')`
  padding: ${p => p.theme.space.md};
`;

const StyledHovercard = styled(Hovercard)`
  width: auto;
  border-radius: ${p => p.theme.radius.md};
  .power-icon {
    padding: 0;
    align-items: center;
  }
`;

export default withSubscription(PowerFeatureHovercard, {noLoader: true});
