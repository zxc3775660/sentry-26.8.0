import {css} from '@emotion/react';
import styled from '@emotion/styled';

import type {ModalRenderProps} from 'sentry/actionCreators/modal';
import {closeModal} from 'sentry/actionCreators/modal';
import {HighlightModalContainer} from 'sentry/components/highlightModalContainer';
import {t, tn} from 'sentry/locale';
import type {Organization} from 'sentry/types/organization';

import {withSubscription} from 'getsentry/components/withSubscription';
import type {Subscription} from 'getsentry/types';
import {
  getTrialDaysLeft,
  getTrialLength,
  hasPerformance,
  isTrial,
} from 'getsentry/utils/billing';

import {Details} from './details';

type Props = ModalRenderProps & {
  organization: Organization;
  source: string;
  subscription: Subscription;
};

function UpsellModal({source, organization, subscription}: Props) {
  const canTrial = subscription.canTrial && !isTrial(subscription);
  const headerMessage = isTrial(subscription) ? (
    <div>
      <Subheader>
        {tn(
          'Trial Active - %s Day Left',
          'Trial Active - %s Days Left',
          getTrialDaysLeft(subscription)
        )}
      </Subheader>
      <Header>{t('Your trial is currently active')}</Header>
    </div>
  ) : hasPerformance(subscription.planDetails) ? (
    <div>
      <Subheader>
        {canTrial
          ? t('%s-day Business Trial', getTrialLength(organization))
          : t('Next stop - Business Plan')}
      </Subheader>
      <Header>{t('Try the upgrade. Regret less.')}</Header>
    </div>
  ) : (
    <div>
      <Subheader>
        {canTrial
          ? t('%s-day Performance Trial', getTrialLength(organization))
          : t("But wait there's more")}
      </Subheader>
      <Header>{t('Get a Performance Boost')}</Header>
    </div>
  );

  return (
    <HighlightModalContainer>
      <div data-test-id="try-business-modal">
        {headerMessage}
        <Details
          source={source}
          subscription={subscription}
          organization={organization}
          onCloseModal={() => closeModal()}
        />
      </div>
    </HighlightModalContainer>
  );
}

const Header = styled('div')`
  font-size: ${p => p.theme.font.size.xl};
  font-weight: bold;
  margin: ${p => p.theme.space.md} 0;
`;

const Subheader = styled('div')`
  text-transform: uppercase;
  font-weight: bold;
  color: ${p => p.theme.tokens.content.accent};
  font-size: ${p => p.theme.font.size.xs};
`;

export const modalCss = css`
  width: 100%;
  max-width: 980px;

  [role='document'] {
    position: relative;
    padding: 70px 80px;
    overflow: hidden;
  }
`;

export default withSubscription(UpsellModal);
