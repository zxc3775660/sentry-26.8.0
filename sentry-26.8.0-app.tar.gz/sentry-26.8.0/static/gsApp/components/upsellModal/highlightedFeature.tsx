import styled from '@emotion/styled';

import {Stack} from '@sentry/scraps/layout';

import {t, tct} from 'sentry/locale';
import type {Organization} from 'sentry/types/organization';

import PlanFeature from 'getsentry/components/features/planFeature';
import type {Subscription} from 'getsentry/types';
import {displayPlanName, hasPerformance, isTrial} from 'getsentry/utils/billing';

import type {Feature} from './types';

type Props = {
  feature: Feature;
  organization: Organization;
  subscription: Subscription;
};

const IMAGE_SIZE = {height: 'auto', width: '540px'};

export function HighlightedFeature({feature, organization, subscription}: Props) {
  return (
    <Stack data-test-id="highlighted-feature">
      <div>{feature.desc}</div>
      {feature.image && <FeatureImg src={feature.image} {...IMAGE_SIZE} />}
      <PlanContext>
        {hasPerformance(subscription.planDetails)
          ? tct("You'll need the [plan] or up to enable this feature.", {
              plan: (
                <PlanFeature
                  {...{organization, subscription}}
                  features={feature.planFeatures}
                >
                  {({plan}) => <strong>{t('%s Plan', displayPlanName(plan))}</strong>}
                </PlanFeature>
              ),
            })
          : tct(
              "You'll need to migrate to a new plan with [strong:Transactions] to enable this feature.",
              {
                strong: <strong />,
              }
            )}
        {!isTrial(subscription) &&
          tct(" You're currently on the [current] plan.", {
            current: subscription.planDetails.name,
          })}
      </PlanContext>
    </Stack>
  );
}

const FeatureImg = styled('img')`
  margin: ${p => p.theme.space.xl} 0;
`;

const PlanContext = styled('div')`
  font-size: ${p => p.theme.font.size.xs};
  line-height: 1.5;
`;
