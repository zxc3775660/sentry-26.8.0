import {Fragment} from 'react';

import {Stack} from '@sentry/scraps/layout';

import {NoProjectMessage} from 'sentry/components/noProjectMessage';
import {Redirect} from 'sentry/components/redirect';
import {NoActiveSeerSubscriptionBanner} from 'sentry/components/seer/noActiveSeerSubscriptionBanner';
import {SeerAutomationDefault} from 'sentry/components/seer/seerAutomationDefault';
import {SeerAutomationProjectList} from 'sentry/components/seer/seerAutomationProjectList';
import {SentryDocumentTitle} from 'sentry/components/sentryDocumentTitle';
import {t} from 'sentry/locale';
import {showNewSeer} from 'sentry/utils/seer/showNewSeer';
import {normalizeUrl} from 'sentry/utils/url/normalizeUrl';
import {useOrganization} from 'sentry/utils/useOrganization';
import {SettingsPageHeader} from 'sentry/views/settings/components/settingsPageHeader';

import {useSubscription} from 'getsentry/hooks/useSubscription';
import {SeerConnectGitHubBanner} from 'getsentry/views/seerAutomation/components/seerConnectGitHubBanner';

export default function SeerAutomation() {
  const subscription = useSubscription();
  const organization = useOrganization();
  const hasSeatBasedSeer = organization.features.includes('seat-based-seer-enabled');
  const hasLegacySeer = organization.features.includes('seer-added');
  const hasCodeReviewBeta = organization.features.includes('code-review-beta');
  const showNoActiveSeerSubscriptionBanner =
    !hasSeatBasedSeer &&
    (hasLegacySeer || hasCodeReviewBeta) &&
    subscription?.canSelfServe;

  if (showNewSeer(organization)) {
    return (
      <Redirect to={normalizeUrl(`/settings/${organization.slug}/seer/projects/`)} />
    );
  }

  // Legacy cohorts continue to use the old automation page.
  return (
    <Fragment>
      <SentryDocumentTitle title={t('Seer Automation')} orgSlug={organization.slug} />
      <SettingsPageHeader
        title={t('Seer Automation')}
        subtitle={t(
          "Choose how Seer automatically triages and diagnoses incoming issues, before you even notice them. This analysis is billed at the standard rates for Seer's Issue Scan and Issue Fix."
        )}
      />

      <NoProjectMessage organization={organization}>
        <Stack gap="lg">
          <SeerConnectGitHubBanner />
          {showNoActiveSeerSubscriptionBanner ? <NoActiveSeerSubscriptionBanner /> : null}
          <SeerAutomationProjectList />
          <br />
          <SeerAutomationDefault />
        </Stack>
      </NoProjectMessage>
    </Fragment>
  );
}
