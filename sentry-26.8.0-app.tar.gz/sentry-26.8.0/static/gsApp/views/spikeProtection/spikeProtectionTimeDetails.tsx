import styled from '@emotion/styled';

import {AlertBadge} from '@sentry/scraps/badge';
import {Stack} from '@sentry/scraps/layout';

import {IconCalendar} from 'sentry/icons';
import {getFormat, getFormattedDate} from 'sentry/utils/dates';
import {IncidentStatus} from 'sentry/views/alerts/types';

import type {SpikeDetails} from 'getsentry/views/spikeProtection/types';

export function SpikeProtectionTimeDetails({spike}: {spike: SpikeDetails}) {
  const {start, end} = spike;
  const format = getFormat({timeOnly: true});
  const formattedTime = end
    ? `${getFormattedDate(start, format)} - ${getFormattedDate(end, format)}`
    : `${getFormattedDate(start, format)} - present`;
  const [startDate, endDate] = [start, end].map(d =>
    getFormattedDate(d, getFormat({dateOnly: true, year: true}))
  );
  const dateFormat =
    startDate === endDate
      ? startDate
      : end
        ? `${startDate} - ${endDate}`
        : `${startDate} - present`;

  return (
    <SpikeTimeDetailsWrapper>
      <AlertBadge status={IncidentStatus.CRITICAL} />
      <Stack>
        <strong>{formattedTime.toLowerCase()}</strong>
        <span>
          <StyledIconCalendar size="xs" variant="muted" />
          {dateFormat}
        </span>
      </Stack>
    </SpikeTimeDetailsWrapper>
  );
}

const SpikeTimeDetailsWrapper = styled('div')`
  display: grid;
  grid-template-columns: 40px auto;
  gap: ${p => p.theme.space.md};
  strong {
    display: block;
    white-space: nowrap;
  }
  span {
    color: ${p => p.theme.tokens.content.secondary};
    display: inline-block;
  }
`;

const StyledIconCalendar = styled(IconCalendar)`
  margin-right: ${p => p.theme.space.xs};
`;
