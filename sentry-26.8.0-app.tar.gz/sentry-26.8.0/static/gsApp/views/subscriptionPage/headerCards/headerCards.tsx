import {Grid} from '@sentry/scraps/layout';

import {ErrorBoundary} from 'sentry/components/errorBoundary';
import type {Organization} from 'sentry/types/organization';
import {useSecondaryNavigation} from 'sentry/views/navigation/secondaryNavigationContext';

import type {Subscription} from 'getsentry/types';
import {hasBillingAccess, isDeveloperPlan, supportsPayg} from 'getsentry/utils/billing';
import {BillingInfoCard} from 'getsentry/views/subscriptionPage/headerCards/billingInfoCard';
import {LinksCard} from 'getsentry/views/subscriptionPage/headerCards/linksCard';
import {NextBillCard} from 'getsentry/views/subscriptionPage/headerCards/nextBillCard';
import {PaygCard} from 'getsentry/views/subscriptionPage/headerCards/paygCard';
import {SeerAutomationAlert} from 'getsentry/views/subscriptionPage/seerAutomationAlert';

interface HeaderCardsProps {
  organization: Organization;
  subscription: Subscription;
}

function getCards(organization: Organization, subscription: Subscription) {
  const hasBillingPerms = hasBillingAccess(organization);
  const cards: React.ReactNode[] = [];
  const isTrialOrFreePlan =
    subscription.onTrialPlan || isDeveloperPlan(subscription.planDetails);

  // the organization can use PAYG
  const canUsePayg = supportsPayg(subscription);

  // the user can update the PAYG budget
  const canUpdatePayg = canUsePayg && hasBillingPerms;

  if (subscription.canSelfServe && !isTrialOrFreePlan && hasBillingPerms) {
    cards.push(
      <NextBillCard
        key="next-bill"
        subscription={subscription}
        organization={organization}
      />
    );
  }

  if (canUsePayg) {
    cards.push(
      <PaygCard key="payg" subscription={subscription} organization={organization} />
    );
  }

  if (
    hasBillingPerms &&
    (canUpdatePayg ||
      (subscription.canSelfServe &&
        isTrialOrFreePlan &&
        !subscription.isEnterpriseTrial)) &&
    !subscription.isSelfServePartner
  ) {
    cards.push(
      <BillingInfoCard
        key="billing-info"
        subscription={subscription}
        organization={organization}
      />
    );
  }

  cards.push(<LinksCard key="links" organization={organization} />);

  return cards;
}

export function HeaderCards({organization, subscription}: HeaderCardsProps) {
  const cards = getCards(organization, subscription);
  const {view} = useSecondaryNavigation();
  const navIsCollapsed = view !== 'expanded';

  return (
    <ErrorBoundary mini>
      <SeerAutomationAlert organization={organization} />
      <Grid
        columns={{
          'screen:xs': '1fr',
          'screen:sm': `repeat(min(${cards.length}, 2), minmax(0, 1fr))`,
          'screen:md': navIsCollapsed
            ? `repeat(${cards.length}, minmax(0, 1fr))`
            : undefined,
          'screen:lg': `repeat(${cards.length}, minmax(0, 1fr))`,
        }}
        gap="lg"
        data-test-id="subscription-header-cards"
      >
        {cards}
      </Grid>
    </ErrorBoundary>
  );
}
