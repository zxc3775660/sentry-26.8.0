import {OrganizationFixture} from 'sentry-fixture/organization';

import {SubscriptionFixture} from 'getsentry-test/fixtures/subscription';
import {render, screen} from 'sentry-test/reactTestingLibrary';
import {resetMockDate, setMockDate} from 'sentry-test/utils';

import {TrialAlert} from 'getsentry/views/subscriptionPage/trialAlert';

describe('Subscription > TrialAlert', () => {
  const organization = OrganizationFixture();
  const subscription = SubscriptionFixture({organization});

  beforeEach(() => {
    setMockDate(new Date('2021-01-01'));
  });

  afterEach(() => {
    resetMockDate();
  });

  it('does not render not on trial', () => {
    const sub = {
      ...subscription,
      trialPlan: null,
      onDemandMaxSpend: 1000,
      onDemandSpendUsed: 0,
    };
    render(<TrialAlert subscription={sub} organization={organization} />);
    expect(screen.queryByRole('button')).not.toBeInTheDocument();
  });

  it('renders 1 day left', () => {
    const sub = {
      ...subscription,
      trialPlan: 'am1_business',
      onDemandMaxSpend: 1000,
      onDemandSpendUsed: 0,
      trialEnd: '2021-01-02',
    };
    render(<TrialAlert subscription={sub} organization={organization} />);
    expect(screen.getByText('1 Day Left')).toBeInTheDocument();
    expect(screen.getByRole('button')).toBeInTheDocument();
  });

  it('renders 14 days left', () => {
    const sub = {
      ...subscription,
      trialPlan: 'am1_business',
      onDemandMaxSpend: 1000,
      onDemandSpendUsed: 0,
      trialEnd: '2021-01-15',
    };
    render(<TrialAlert subscription={sub} organization={organization} />);
    expect(screen.getByText('14 Days Left')).toBeInTheDocument();
    expect(screen.getByRole('button')).toBeInTheDocument();
  });

  it('does not render negative days left', () => {
    const sub = {
      ...subscription,
      trialPlan: 'am1_business',
      onDemandMaxSpend: 1000,
      onDemandSpendUsed: 0,
      trialEnd: '2020-12-01',
    };
    render(<TrialAlert subscription={sub} organization={organization} />);
    expect(screen.queryByRole('button')).not.toBeInTheDocument();
  });

  it('renders enterprise trial', () => {
    const sub = {
      ...subscription,
      trialPlan: 'am1_business',
      isEnterpriseTrial: true,
      onDemandMaxSpend: 1000,
      onDemandSpendUsed: 0,
    };
    render(<TrialAlert subscription={sub} organization={organization} />);
    expect(screen.getByText('Enterprise Trial')).toBeInTheDocument();
    expect(
      screen.getByText(
        "With your trial you have access to Sentry's business plan features."
      )
    ).toBeInTheDocument();
  });

  it('renders am3 enterprise trial', () => {
    const am3_sub = SubscriptionFixture({organization, plan: 'am3_f'});
    const sub = {
      ...am3_sub,
      trialPlan: 'am1_business',
      isEnterpriseTrial: true,
      onDemandMaxSpend: 1000,
      onDemandSpendUsed: 0,
    };
    render(<TrialAlert subscription={sub} organization={organization} />);
    expect(screen.getByText('Enterprise Trial')).toBeInTheDocument();
    expect(
      screen.getByText(
        "With your trial you have access to Sentry's business plan features."
      )
    ).toBeInTheDocument();
  });

  it('renders plan trial', () => {
    const sub = {
      ...subscription,
      trialPlan: 'am1_business',
      isEnterpriseTrial: false,
      onDemandMaxSpend: 1000,
      onDemandSpendUsed: 0,
    };
    render(<TrialAlert subscription={sub} organization={organization} />);
    expect(screen.getByText('Business Plan Trial')).toBeInTheDocument();
    expect(
      screen.getByText(
        "With your trial you have access to Sentry's business plan features."
      )
    ).toBeInTheDocument();
    expect(screen.queryByText(/unlimited errors/)).not.toBeInTheDocument();
  });
});
