import {Flex, Stack} from '@sentry/scraps/layout';
import {Heading, Text} from '@sentry/scraps/text';

import {PAYG_BUSINESS_DEFAULT, PAYG_TEAM_DEFAULT} from 'getsentry/constants';
import {OnDemandBudgetMode, type Plan} from 'getsentry/types';
import {isBizPlanFamily} from 'getsentry/utils/billing';
import {CheckoutOption} from 'getsentry/views/amCheckout/components/checkoutOption';
import type {CheckoutFormData, PlanContent} from 'getsentry/views/amCheckout/types';
import {getShortInterval} from 'getsentry/views/amCheckout/utils';

interface PlanSelectCardProps {
  isSelected: boolean;
  onUpdate: (data: Partial<CheckoutFormData>) => void;
  plan: Plan;
  planContent: PlanContent;
  planName: string;
  planValue: string;
  price: string;
  /**
   * Flag to show default pay as you go values
   */
  shouldShowDefaultPayAsYouGo: boolean;
  badge?: React.ReactNode;
}

export function PlanSelectCard({
  plan,
  isSelected,
  onUpdate,
  planName,
  planContent,
  price,
  badge,
  shouldShowDefaultPayAsYouGo,
}: PlanSelectCardProps) {
  const billingInterval = getShortInterval(plan.billingInterval);
  const {description} = planContent;

  const onPlanSelect = () => {
    const data: Partial<CheckoutFormData> = {plan: plan.id};
    if (shouldShowDefaultPayAsYouGo) {
      data.onDemandMaxSpend = isBizPlanFamily(plan)
        ? PAYG_BUSINESS_DEFAULT
        : PAYG_TEAM_DEFAULT;
      data.onDemandBudget = {
        budgetMode: OnDemandBudgetMode.SHARED,
        sharedMaxBudget: data.onDemandMaxSpend,
      };
    }
    onUpdate(data);
  };

  return (
    <CheckoutOption
      dataTestId={`plan-option-${plan.id}`}
      ariaLabel={planName}
      isSelected={isSelected}
      onClick={onPlanSelect}
      ariaRole="radio"
      optionHeader={
        <Flex align="center" justify="between" gap="sm" flexGrow={1}>
          <Flex align="center" gap="sm">
            <Heading as="h3" variant="primary">
              {planName}
            </Heading>
            {badge}
          </Flex>

          <Flex>
            <Text size="lg" bold>
              {`$${price}`}
            </Text>
            <Text size="lg" variant="muted">
              {`/${billingInterval}`}
            </Text>
          </Flex>
        </Flex>
      }
      optionDescription={
        <Stack gap="sm" width="100%">
          <Text size="md" variant="muted" textWrap="balance">
            {description}
          </Text>
        </Stack>
      }
    />
  );
}
