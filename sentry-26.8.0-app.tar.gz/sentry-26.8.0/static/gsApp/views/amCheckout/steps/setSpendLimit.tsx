import {Stack} from '@sentry/scraps/layout';

import {t} from 'sentry/locale';

import type {OnDemandBudgets} from 'getsentry/types';
import {displayBudgetName} from 'getsentry/utils/billing';
import {trackGetsentryAnalytics} from 'getsentry/utils/trackGetsentryAnalytics';
import {StepHeader} from 'getsentry/views/amCheckout/components/stepHeader';
import {ReserveAdditionalVolume} from 'getsentry/views/amCheckout/steps/reserveAdditionalVolume';
import type {StepProps} from 'getsentry/views/amCheckout/types';
import {SpendLimitSettings} from 'getsentry/views/spendLimits/spendLimitSettings';
import {
  getTotalBudget,
  parseOnDemandBudgetsFromSubscription,
} from 'getsentry/views/spendLimits/utils';

export function SetSpendLimit({
  activePlan,
  formData,
  stepNumber,
  onUpdate,
  organization,
  subscription,
}: StepProps) {
  const handleBudgetChange = ({onDemandBudgets}: {onDemandBudgets: OnDemandBudgets}) => {
    const totalBudget = getTotalBudget(onDemandBudgets);
    onUpdate({
      ...formData,
      onDemandBudget: onDemandBudgets,
      onDemandMaxSpend: totalBudget,
    });

    if (organization) {
      trackGetsentryAnalytics('checkout.payg_changed', {
        organization,
        subscription,
        plan: formData.plan,
        cents: totalBudget || 0,
        method: 'textbox',
      });
    }
  };

  return (
    <Stack gap="2xl" id={`step${stepNumber}`}>
      <SpendLimitSettings
        organization={organization}
        subscription={subscription}
        header={
          <StepHeader title={t('Set your %s limit', displayBudgetName(activePlan))} />
        }
        activePlan={activePlan}
        onDemandBudgets={
          formData.onDemandBudget ?? parseOnDemandBudgetsFromSubscription(subscription)
        }
        onUpdate={({onDemandBudgets}) => handleBudgetChange({onDemandBudgets})}
        currentReserved={formData.reserved}
        addOns={formData.addOns ?? {}}
        footer={
          <ReserveAdditionalVolume
            activePlan={activePlan}
            formData={formData}
            onUpdate={onUpdate}
            organization={organization}
            subscription={subscription}
          />
        }
      />
    </Stack>
  );
}
