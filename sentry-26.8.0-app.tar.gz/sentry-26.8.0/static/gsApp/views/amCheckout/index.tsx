import {Fragment, useCallback, useEffect, useMemo, useRef, useState} from 'react';
import styled from '@emotion/styled';
import * as Sentry from '@sentry/react';
import {loadStripe} from '@stripe/stripe-js';
import type {Location} from 'history';
import isEqual from 'lodash/isEqual';
import moment from 'moment-timezone';

import {Alert} from '@sentry/scraps/alert';
import {Button, LinkButton} from '@sentry/scraps/button';
import {Flex, Grid, Stack} from '@sentry/scraps/layout';
import {ExternalLink} from '@sentry/scraps/link';
import {Text} from '@sentry/scraps/text';

import type {Client} from 'sentry/api';
import {LoadingError} from 'sentry/components/loadingError';
import {LoadingIndicator} from 'sentry/components/loadingIndicator';
import {LogoSentry} from 'sentry/components/logoSentry';
import {SentryDocumentTitle} from 'sentry/components/sentryDocumentTitle';
import {IconChevron} from 'sentry/icons';
import {t, tct} from 'sentry/locale';
import {ConfigStore} from 'sentry/stores/configStore';
import {DataCategory} from 'sentry/types/core';
import {showIntercom} from 'sentry/utils/intercom';
import {normalizeUrl} from 'sentry/utils/url/normalizeUrl';
import type {ReactRouter3Navigate} from 'sentry/utils/useNavigate';
import {useOrganization} from 'sentry/utils/useOrganization';
import {withApi} from 'sentry/utils/withApi';

import {withSubscription} from 'getsentry/components/withSubscription';
import {
  ANNUAL,
  BillingConfigTier,
  PAYG_BUSINESS_DEFAULT,
  PAYG_TEAM_DEFAULT,
} from 'getsentry/constants';
import {OnDemandBudgetMode, PlanName} from 'getsentry/types';
import type {
  BillingConfig,
  CheckoutAddOns,
  EventBucket,
  Invoice,
  OnDemandBudgets,
  Plan,
  PreviewData,
  Subscription,
} from 'getsentry/types';
import {
  hasActiveVCFeature,
  hasPartnerMigrationFeature,
  hasPerformance,
  isBizPlanFamily,
  isNewPayingCustomer,
  isTrial,
} from 'getsentry/utils/billing';
import {trackGetsentryAnalytics} from 'getsentry/utils/trackGetsentryAnalytics';
import {Cart} from 'getsentry/views/amCheckout/components/cart';
import {CheckoutSuccess} from 'getsentry/views/amCheckout/components/checkoutSuccess';
import {AddBillingInformation} from 'getsentry/views/amCheckout/steps/addBillingInfo';
import {BuildYourPlan} from 'getsentry/views/amCheckout/steps/buildYourPlan';
import {ChooseYourBillingCycle} from 'getsentry/views/amCheckout/steps/chooseYourBillingCycle';
import {SetSpendLimit} from 'getsentry/views/amCheckout/steps/setSpendLimit';
import type {CheckoutFormData} from 'getsentry/views/amCheckout/types';
import {getBucket} from 'getsentry/views/amCheckout/utils';
import {
  getTotalBudget,
  hasOnDemandBudgetsFeature,
  parseOnDemandBudgetsFromSubscription,
} from 'getsentry/views/spendLimits/utils';

type Props = {
  api: Client;
  location: Location;
  navigate: ReactRouter3Navigate;
  subscription: Subscription;
};

export type State = {
  billingConfig: BillingConfig | null;
  error: Error | boolean;
  formData: CheckoutFormData | null;
  formDataForPreview: CheckoutFormData | null;
  isSubmitted: boolean;
  loading: boolean;
  nextQueryParams: string[];
  invoice?: Invoice;
  previewData?: PreviewData;
};

function AMCheckout(props: Props) {
  const organization = useOrganization();
  const {api, location, navigate, subscription} = props;

  const hasFetchedBillingConfig = useRef(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | boolean>(false);
  const [formData, setFormData] = useState<CheckoutFormData | null>(null);
  const [formDataForPreview, setFormDataForPreview] = useState<CheckoutFormData | null>(
    null
  );
  const [billingConfig, setBillingConfig] = useState<BillingConfig | null>(null);
  const [nextQueryParams, setNextQueryParams] = useState<string[]>([]);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [invoice, setInvoice] = useState<Invoice | undefined>(undefined);
  const [previewData, setPreviewData] = useState<PreviewData | undefined>(undefined);

  const referrer = useMemo(() => {
    if (Array.isArray(location?.query?.referrer)) {
      return location?.query?.referrer[0];
    }
    return location?.query?.referrer ?? undefined;
  }, [location]);

  const checkoutSteps = useMemo(() => {
    // Do not include Payment Method and Billing Details sections for subscriptions billed through partners
    if (subscription.isSelfServePartner) {
      if (hasActiveVCFeature(organization)) {
        // Don't allow VC customers to choose Annual plans
        return [BuildYourPlan, SetSpendLimit];
      }

      return [BuildYourPlan, SetSpendLimit, ChooseYourBillingCycle];
    }
    return [BuildYourPlan, SetSpendLimit, ChooseYourBillingCycle, AddBillingInformation];
  }, [subscription.isSelfServePartner, organization]);

  const activePlan = useMemo(() => {
    if (!formData || !billingConfig) {
      return null;
    }
    const plan = billingConfig.planList.find(({id}) => id === formData.plan);
    if (!plan) {
      throw new Error('Cannot get active plan');
    }
    return plan;
  }, [formData, billingConfig]);

  const getPlan = useCallback(
    (planId: string) => {
      return billingConfig?.planList.find(({id}) => id === planId);
    },
    [billingConfig]
  );

  /**
   * Managed subscriptions need to go through Sales or Support to make
   * changes to their plan and cannot use the self-serve checkout flow
   */
  const handleRedirect = useCallback(() => {
    return navigate(normalizeUrl(`/settings/${organization.slug}/billing/overview/`));
  }, [navigate, organization.slug]);

  const getPlans = useCallback((config: BillingConfig) => {
    const plans = config.planList.filter(
      plan =>
        plan.id === config.freePlan || Boolean(plan.basePrice && plan.userSelectable)
    );

    if (plans.length === 0) {
      throw new Error('Cannot get plan options');
    }
    return plans;
  }, []);

  /**
   * Default to the business plan if:
   * 1. The account has an upsell/upgrade referrer
   * 2. The subscription is free
   * 3. Or, the subscription is on a free trial
   */
  const subscriptionIsTrial = isTrial(subscription);
  const shouldDefaultToBusiness = useCallback(() => {
    const hasUpsell = referrer?.startsWith('upgrade') || referrer?.startsWith('upsell');

    return hasUpsell || subscription.isFree || subscriptionIsTrial;
  }, [referrer, subscription.isFree, subscriptionIsTrial]);

  const getBusinessPlan = useCallback(
    (config: BillingConfig) => {
      const {planList} = config;

      return planList.find(({name, billingInterval}) => {
        return (
          name === 'Business' &&
          billingInterval === subscription?.planDetails?.billingInterval
        );
      });
    },
    [subscription?.planDetails?.billingInterval]
  );

  /**
   * Logic for initial plan:
   * 1. Default to the business plan
   * 2. Then default to the current paid plan
   * 3. Then default to an equivalent paid plan (mm2 Business -> am1 Business)
   * 4. Then default to the server default plan (Team)
   */
  const getInitialPlan = useCallback(
    (config: BillingConfig) => {
      const {planList, defaultPlan} = config;
      const initialPlan = planList.find(({id}) => id === subscription.plan);
      const businessPlan = getBusinessPlan(config);

      if (shouldDefaultToBusiness()) {
        if (businessPlan) {
          return businessPlan;
        }
      }

      // Current tier paid plan
      if (initialPlan) {
        return initialPlan;
      }

      // map bundle plans
      if (subscription.planDetails.name === PlanName.BUSINESS_BUNDLE) {
        return planList.find(
          p => p.name === PlanName.BUSINESS && p.billingInterval === 'monthly'
        );
      }
      if (subscription.planDetails.name === PlanName.TEAM_BUNDLE) {
        return planList.find(
          p => p.name === PlanName.TEAM && p.billingInterval === 'monthly'
        );
      }

      // The current plan isn't directly available in this checkout's plan list
      // (the exact-id lookup above returned nothing), so fall back to an
      // equivalent plan matched by name + contract interval.
      const legacyInitialPlan = planList.find(
        ({name, billingInterval}) =>
          name === subscription?.planDetails?.name &&
          billingInterval === subscription?.planDetails?.billingInterval
      );

      // if no legacy initial plan found, we fallback to the business plan, then the default plan (usually team)
      return (
        legacyInitialPlan || businessPlan || planList.find(({id}) => id === defaultPlan)
      );
    },
    [
      subscription.plan,
      subscription.planDetails.name,
      subscription.planDetails?.billingInterval,
      getBusinessPlan,
      shouldDefaultToBusiness,
    ]
  );

  const canComparePrices = useCallback(
    (initialPlan: Plan) => {
      return (
        // MMx event buckets are priced differently
        hasPerformance(subscription?.planDetails) &&
        subscription.planDetails.name === initialPlan.name &&
        subscription.planDetails.billingInterval === initialPlan.billingInterval
      );
    },
    [subscription?.planDetails]
  );

  const getValidData = useCallback(
    (plan: Plan, data: Omit<CheckoutFormData, 'plan'>): CheckoutFormData => {
      const {onDemandMaxSpend, onDemandBudget, addOns} = data;

      // Verify next plan data volumes before updating form data
      // finds the approximate bucket if event level does not exist
      const nextReserved = Object.fromEntries(
        Object.entries(data.reserved).map(([category, value]) => [
          category,
          getBucket({
            events: value,
            buckets: plan.planCategories[category as DataCategory],
            shouldMinimize: hasPartnerMigrationFeature(organization),
          }).events,
        ])
      );

      const onDemandSupported = plan.allowOnDemand && subscription.supportsOnDemand;

      // reset ondemand if not allowed or supported
      let newOnDemandMaxSpend = onDemandSupported ? onDemandMaxSpend : 0;
      if (typeof newOnDemandMaxSpend === 'number') {
        newOnDemandMaxSpend = Math.max(newOnDemandMaxSpend, 0);
      }

      let newOnDemandBudget: OnDemandBudgets | undefined = undefined;

      if (
        hasOnDemandBudgetsFeature(organization, subscription) ||
        plan.categories.includes(DataCategory.SPANS)
      ) {
        newOnDemandBudget =
          onDemandBudget && onDemandSupported
            ? onDemandBudget
            : {
                budgetMode: OnDemandBudgetMode.SHARED,
                sharedMaxBudget: 0,
              };

        newOnDemandMaxSpend = getTotalBudget(newOnDemandBudget);
      }

      return {
        plan: plan.id,
        onDemandMaxSpend: newOnDemandMaxSpend,
        onDemandBudget: newOnDemandBudget,
        reserved: nextReserved,
        addOns,
      };
    },
    [organization, subscription]
  );

  /**
   * Get the current subscription plan and event volumes.
   * If not available on current tier, use the default plan.
   */
  const getInitialData = useCallback(
    (config: BillingConfig): CheckoutFormData => {
      const {onDemandMaxSpend, planDetails} = subscription;

      const initialPlan = getInitialPlan(config);

      if (!initialPlan) {
        throw new Error('Cannot get initial plan');
      }

      const canCompare = canComparePrices(initialPlan);

      // Default to the max event volume per category based on either
      // the current reserved volume or the current reserved price.
      const reserved = Object.fromEntries(
        (
          Object.entries(planDetails.planCategories) as Array<
            [DataCategory, EventBucket[]]
          >
        )
          .filter(([category, _]) => initialPlan.planCategories[category])
          .map(([category, eventBuckets]) => {
            const currentHistory = subscription.categories[category];
            // When introducing a new category before backfilling, the reserved value from the billing metric
            // history is not available, so we default to 0.
            // Skip trial volumes - don't pre-fill with trial reserved amounts
            let events = (!subscription.onTrialPlan && currentHistory?.reserved) || 0;

            if (canCompare) {
              const price = getBucket({events, buckets: eventBuckets}).price;
              const eventsByPrice = getBucket({
                price,
                buckets: initialPlan.planCategories[category],
              }).events;
              events = Math.max(events, eventsByPrice);
            }
            return [category, events];
          })
      );

      const defaultReservedCategories = Object.entries(config.defaultReserved).map(
        ([k, _]) => k
      );
      // this is the customer's reserved values that overlap with
      // the categories in the new checkout plan
      // e.g. AM2 customers checking out an AM3 plan will have
      // reserved transactions in AM2 but do not need reserved transactions in AM3
      const reservedOverlapping = Object.fromEntries(
        Object.entries(reserved).filter(([k, _]) => defaultReservedCategories.includes(k))
      );

      const data = {
        reserved: {
          ...config.defaultReserved,
          ...reservedOverlapping,
        },
        ...(onDemandMaxSpend > 0 && {onDemandMaxSpend}),
        onDemandBudget: parseOnDemandBudgetsFromSubscription(subscription),
        addOns: Object.values(subscription.addOns ?? {})
          .filter(
            // only populate add-ons that are launched
            addOn => addOn.isAvailable
          )
          .reduce<CheckoutAddOns>((acc, addOn) => {
            acc[addOn.apiName] = {
              // don't prepopulate add-ons from trial state
              enabled: addOn.enabled && !subscription.onTrialPlan,
            };
            return acc;
          }, {}),
      };

      if (isNewPayingCustomer(subscription, organization)) {
        data.onDemandMaxSpend = isBizPlanFamily(initialPlan)
          ? PAYG_BUSINESS_DEFAULT
          : PAYG_TEAM_DEFAULT;
        data.onDemandBudget = {
          budgetMode: OnDemandBudgetMode.SHARED,
          sharedMaxBudget: data.onDemandMaxSpend,
        };
      }

      return getValidData(initialPlan, data);
    },
    [subscription, organization, getInitialPlan, canComparePrices, getValidData]
  );

  const getFormDataForPreview = useCallback((data: CheckoutFormData) => {
    return {
      ...data,
      onDemandBudget: undefined,
      onDemandMaxSpend: undefined,
    };
  }, []);

  const fetchBillingConfig = useCallback(async () => {
    setLoading(true);
    const endpoint = `/customers/${organization.slug}/billing-config/`;

    try {
      const config = await api.requestPromise(endpoint, {
        method: 'GET',
        // The endpoint resolves the concrete checkout tier server-side (it
        // mirrors the selection in `decideCheckout`).
        data: {tier: BillingConfigTier.CHECKOUT},
      });

      const planList = getPlans(config);
      const newBillingConfig = {...config, planList};
      const initialFormData = getInitialData(newBillingConfig);

      setBillingConfig(newBillingConfig);
      setFormData(initialFormData);
      setFormDataForPreview(getFormDataForPreview(initialFormData));
    } catch (err: any) {
      setError(err);
      setLoading(false);
      if (err.status !== 401 && err.status !== 403) {
        Sentry.captureException(err);
      }
    }

    setLoading(false);
  }, [api, organization.slug, getPlans, getInitialData, getFormDataForPreview]);

  const scrollToStep = useCallback(() => {
    const hash = location?.hash;

    if (!hash) {
      return;
    }

    // Parse step number from hash like #step1, #step2, etc.
    const stepMatch = /^#step(\d+)$/.exec(hash);
    if (!stepMatch) {
      return;
    }

    const stepNumber = parseInt(stepMatch[1]!, 10);
    if (stepNumber < 1 || stepNumber > checkoutSteps.length) {
      return;
    }

    // Use requestAnimationFrame to ensure DOM is ready
    requestAnimationFrame(() => {
      const stepElement = document.getElementById(`step${stepNumber}`);
      if (stepElement) {
        // TODO(isabella): We should calculate some offset to add to account for the sticky header (which covers the title)
        // and we will likely need to take screen size into account (steps 3 and 4 cannot have their headers at the top of the viewport unless it's a smaller screen)
        const targetScrollY = stepElement.getBoundingClientRect().top + window.scrollY;
        window.scrollTo({top: targetScrollY, behavior: 'smooth'});
      }
    });
  }, [location?.hash, checkoutSteps.length]);

  const handleUpdate = useCallback(
    (updatedData: any) => {
      if (!formData || !activePlan) {
        return;
      }

      const data = {...formData, ...updatedData};
      const plan = getPlan(data.plan) || activePlan;
      const validData = getValidData(plan, data);
      let validPreviewData: CheckoutFormData | null = getFormDataForPreview(validData);
      if (isEqual(validPreviewData, formDataForPreview)) {
        validPreviewData = formDataForPreview;
      }

      setFormData(validData);
      setFormDataForPreview(validPreviewData);

      if (!isEqual(validData.reserved, data.reserved)) {
        Sentry.withScope(scope => {
          scope.setExtras({validData, updatedData, previous: formData});
          scope.setLevel('warning');
          Sentry.captureException(new Error('Plan event levels do not match'));
        });
      }
    },
    [
      formData,
      formDataForPreview,
      activePlan,
      getPlan,
      getValidData,
      getFormDataForPreview,
    ]
  );

  useEffect(() => {
    /**
     * Preload Stripe so it's ready when the subscription + cc form becomes
     * available. `loadStripe` ensures Stripe is not loaded multiple times
     */
    loadStripe(ConfigStore.get('getsentry.stripePublishKey')!);
  }, []);

  useEffect(() => {
    trackGetsentryAnalytics('am_checkout.viewed', {
      organization,
      subscription,
    });

    Sentry.getReplay()?.start();
  }, [organization, subscription]);

  useEffect(() => {
    trackGetsentryAnalytics('intercom_link.viewed', {
      organization,
      source: 'checkout',
    });
  }, [organization]);

  useEffect(() => {
    if (subscription.canSelfServe) {
      if (!hasFetchedBillingConfig.current) {
        hasFetchedBillingConfig.current = true;
        fetchBillingConfig();
      }
    } else {
      handleRedirect();
    }
  }, [subscription.canSelfServe, fetchBillingConfig, handleRedirect]);

  // Scroll to step after billing config and form data are ready
  useEffect(() => {
    if (billingConfig && formData) {
      scrollToStep();
    }
  }, [billingConfig, formData, scrollToStep]);

  const renderSteps = useCallback(() => {
    if (!formData || !billingConfig || !activePlan) {
      return null;
    }

    const stepProps = {
      formData,
      billingConfig,
      activePlan,
      onUpdate: handleUpdate,
      organization,
      subscription,
    };

    return checkoutSteps.map((CheckoutStep, idx) => {
      const stepNumber = idx + 1;
      return (
        <CheckoutStep
          {...stepProps}
          key={idx}
          referrer={referrer}
          stepNumber={stepNumber}
        />
      );
    });
  }, [
    formData,
    billingConfig,
    activePlan,
    handleUpdate,
    organization,
    subscription,
    checkoutSteps,
    referrer,
  ]);

  const renderPartnerAlert = useCallback(() => {
    if (!subscription.isSelfServePartner) {
      return null;
    }

    return (
      <Alert.Container>
        <Alert variant="info">
          <Stack gap="md">
            <Text bold>
              {tct('Billing handled externally through [partnerName]', {
                partnerName: subscription.partner?.partnership.displayName,
              })}
            </Text>
            {tct(
              'Payments for this subscription are processed by [partnerName]. Please make sure your payment method is up to date on their platform to avoid service interruptions.',
              {
                partnerName: subscription.partner?.partnership.displayName,
              }
            )}
          </Stack>
        </Alert>
      </Alert.Container>
    );
  }, [subscription]);

  if (loading) {
    return <LoadingIndicator />;
  }

  if (error) {
    return <LoadingError />;
  }

  if (!formData || !billingConfig || !formDataForPreview || !activePlan) {
    return null;
  }

  if (isSubmitted) {
    const purchasedPlanItem = invoice?.items.find(item => item.type === 'subscription');
    const basePlan = purchasedPlanItem
      ? getPlan(purchasedPlanItem.data.plan)
      : getPlan(formData.plan);

    return (
      <Grid columns="1fr" rows="max-content 1fr" minHeight="100vh" background="primary">
        <SentryDocumentTitle
          title={t('Checkout Completed')}
          orgSlug={organization.slug}
        />
        <Flex width="100%" justify="center" borderBottom="primary">
          <Flex width="100%" justify="start" padding="2xl" maxWidth="1440px">
            <LogoSentry />
          </Flex>
        </Flex>
        <Flex height="100%" align="center" justify="center">
          <CheckoutSuccess
            invoice={invoice}
            nextQueryParams={nextQueryParams}
            basePlan={basePlan}
            previewData={previewData}
          />
        </Flex>
      </Grid>
    );
  }

  const overviewProps = {
    formData,
    billingConfig,
    activePlan,
    onUpdate: handleUpdate,
    organization,
    subscription,
  };

  const showAnnualTerms =
    subscription.billingInterval === ANNUAL || activePlan.billingInterval === ANNUAL;

  const isOnSponsoredPartnerPlan =
    (subscription.partner?.isActive && subscription.isSponsored) || false;

  const renderCheckoutContent = () => (
    <Fragment>
      <CheckoutBody>
        {renderPartnerAlert()}
        <CheckoutStepsContainer data-test-id="checkout-steps">
          {renderSteps()}
        </CheckoutStepsContainer>
      </CheckoutBody>
      <SidePanel>
        <OverviewContainer>
          <Cart
            {...overviewProps}
            referrer={referrer}
            formDataForPreview={formDataForPreview}
            onSuccess={params => {
              setInvoice(params.invoice);
              setNextQueryParams(params.nextQueryParams);
              setIsSubmitted(params.isSubmitted);
              setPreviewData(params.previewData);
            }}
          />

          <Stack padding="xl" gap="xl">
            <Flex justify="between" gap="xl" align="center">
              {t('Have a question?')}
              <Text align="right">
                {tct('[help:Find an answer] or [contact]', {
                  help: (
                    <ExternalLink href="https://www.sentry.help/en/collections/18842102-account-billing" />
                  ),
                  contact: (
                    <Button
                      size="zero"
                      variant="link"
                      onClick={async () => {
                        trackGetsentryAnalytics('intercom_link.clicked', {
                          organization,
                          source: 'checkout',
                        });
                        try {
                          await showIntercom(organization.slug);
                        } catch {
                          // Fall back to mailto
                          const supportEmail = ConfigStore.get('supportEmail');
                          if (supportEmail) {
                            window.location.href = `mailto:${supportEmail}?subject=${window.encodeURIComponent('Billing Question')}`;
                          }
                        }
                      }}
                    >
                      <Text variant="accent">{t('ask Support')}</Text>
                    </Button>
                  ),
                })}
              </Text>
            </Flex>
            {subscription.canCancel && (
              <LinkButton
                to={`/settings/${organization.slug}/billing/cancel/`}
                disabled={subscription.cancelAtPeriodEnd}
                size="sm"
              >
                {subscription.cancelAtPeriodEnd
                  ? t('Pending Cancellation')
                  : t('Cancel Subscription')}
              </LinkButton>
            )}
            {showAnnualTerms && (
              <Text size="xs" align="center" variant="muted">
                {tct(
                  'Annual subscriptions require a one-year non-cancellable commitment. By using Sentry you agree to our [terms: Terms of Service].',
                  {terms: <a href="https://sentry.io/terms/" />}
                )}
              </Text>
            )}
          </Stack>
        </OverviewContainer>
      </SidePanel>
    </Fragment>
  );

  return (
    <Stack width="100%" background="primary" justify="center" align="center">
      <SentryDocumentTitle title={t('Change Subscription')} orgSlug={organization.slug} />
      {isOnSponsoredPartnerPlan && (
        <Alert.Container>
          <Alert variant="info">
            {t(
              'Your promotional plan with %s ends on %s.',
              subscription.partner?.partnership.displayName,
              moment(subscription.billingPeriodEnd).format('ll')
            )}
          </Alert>
        </Alert.Container>
      )}
      <CheckoutHeader>
        <Flex width="100%" align="center" maxWidth="82rem" gap="lg" padding="lg 2xl">
          <LogoSentry height="20px" />
          <LinkButton
            to={`/settings/${organization.slug}/billing/`}
            icon={<IconChevron direction="left" />}
            size="xs"
            variant="transparent"
            onClick={() => {
              trackGetsentryAnalytics('checkout.exit', {
                subscription,
                organization,
              });
            }}
          >
            {t('Manage Subscription')}
          </LinkButton>

          <OrgSlug>{organization.slug.toUpperCase()}</OrgSlug>
        </Flex>
      </CheckoutHeader>

      <Flex
        direction={{'screen:xs': 'column', 'screen:md': 'row'}}
        gap="md 3xl"
        justify="between"
        width="100%"
        maxWidth="82rem"
        align="start"
        paddingTop="3xl"
      >
        {renderCheckoutContent()}
      </Flex>
    </Stack>
  );
}

const CheckoutHeader = styled('header')`
  position: sticky;
  top: 0;
  left: 0;
  right: 0;
  z-index: 100;
  width: 100%;
  background: ${p => p.theme.tokens.background.primary};
  border-bottom: 1px solid ${p => p.theme.tokens.border.primary};
  display: flex;
  justify-content: center;
  gap: ${p => p.theme.space.md};
`;

const OrgSlug = styled('div')`
  font-family: ${p => p.theme.font.family.mono};
  color: ${p => p.theme.tokens.content.secondary};
  text-overflow: ellipsis;
  text-wrap: nowrap;
  flex: 1;
  text-align: right;
`;

const CheckoutBody = styled('div')`
  padding: 0 ${p => p.theme.space['2xl']} ${p => p.theme.space['3xl']}
    ${p => p.theme.space['2xl']};
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  @media (min-width: ${p => p.theme.breakpoints.md}) {
    max-width: 47.5rem;
    padding-top: ${p => p.theme.space.md};
  }
`;

const SidePanel = styled('aside')`
  width: 100%;
  border-top: 1px solid ${p => p.theme.tokens.border.primary};
  display: flex;
  flex-direction: column;
  padding: 0 ${p => p.theme.space['2xl']};
  background-color: ${p => p.theme.tokens.background.secondary};

  @media (min-width: ${p => p.theme.breakpoints.md}) {
    position: sticky;
    right: 0;
    top: 6.25rem;
    max-width: 26rem;
    border-top: none;
    padding-left: ${p => p.theme.space['3xl']};
    background-color: ${p => p.theme.tokens.background.primary};
    padding-bottom: ${p => p.theme.space['3xl']};
  }
`;

/**
 * Hide overview at smaller screen sizes in old checkout
 * Bring overview to bottom at smaller screen sizes in new checkout
 * Cancel subscription button is always visible
 */
const OverviewContainer = styled('div')`
  flex: 1;
  display: flex;
  flex-direction: column;
  position: relative;
  gap: ${p => p.theme.space.xl};
  padding: ${p => p.theme.space['2xl']} 0;

  @media (min-width: ${p => p.theme.breakpoints.md}) {
    padding: 0;
  }
`;

const CheckoutStepsContainer = styled('div')`
  display: flex;
  flex-direction: column;
  gap: ${p => p.theme.space['3xl']};

  & > * + * {
    border-top: 1px solid ${p => p.theme.tokens.border.primary};
    padding-top: ${p => p.theme.space['3xl']};
    margin-top: ${p => p.theme.space['3xl']};
  }
`;

export default withApi(withSubscription(AMCheckout));
